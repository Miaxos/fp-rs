fp-rs
====

<div align="center">
 <!-- CI -->
 <img src="https://github.com/Miaxos/fp-rs/actions/workflows/ci.yml/badge.svg" />
 <!-- Crates version -->
 <a href="https://crates.io/crates/fp-rs">
   <img src="https://img.shields.io/crates/v/fp-rs.svg?style=flat-square"
   alt="Crates.io version" />
 </a>
 <!-- Downloads -->
 <a href="https://crates.io/crates/fp-rs">
   <img src="https://img.shields.io/crates/d/fp-rs.svg?style=flat-square"
     alt="Download" />
 </a>
</div>
<br />
<br />


`fp-rs` is a library for *functional programming in Rust*.

## References

* [Haskell](https://www.haskell.org/)
* [Purescript](https://www.purescript.org/)
* [Scala](https://scala-lang.org/)
* [fp-ts](https://github.com/gcanti/fp-ts)
